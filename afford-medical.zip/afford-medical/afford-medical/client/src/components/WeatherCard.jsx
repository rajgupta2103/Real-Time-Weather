import React from 'react';

const WeatherCard = ({ weather }) => {
  return (
    <div style={{ marginTop: '1rem' }}>
      <h2>{weather.condition}</h2>
      <img src={weather.icon} alt={weather.condition} />
      <p>Temperature: {weather.temperature}°C</p>
      <p>Humidity: {weather.humidity}%</p>
      <p>Wind Speed: {weather.windSpeed} m/s</p>
    </div>
  );
};

export default WeatherCard;
